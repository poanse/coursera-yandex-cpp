#include "tests.h"

#include "run.h"
#include "test_runner.h"
#include "route.h"
#include "json.h"
#include "parse_json.h"
#include "requests.h"
#include "responses.h"
#include "stop_pair.h"

#include <fstream>

using namespace std;

ostream& operator<< (ostream& os, const list<string>& list) {
	auto it = list.begin();
	for (; it != prev(list.end()); it++) {
		os << '"' << *it << '"' << ", ";
	}
	os << '"' << *it << '"';
	return os;
}

void TestSplitBySubstring() {
	string str = "Tolstopaltsevo - Marushkino - Rasskazovka";
	auto l = SplitBySubstring(str, " - ");
	vector<string> stops = {"Tolstopaltsevo", "Marushkino", "Rasskazovka"};
	ASSERT_EQUAL(l, stops);
}

// void TestReadAddRequest() {
// 	{
// 		string input = "Stop Tolstopaltsevo: 55.611087, 37.20829\n";
// 		stringstream sstream(input);
// 		auto req_ptr = ReadAddRequest(sstream);
// 		ASSERT_EQUAL(AddRequest::Type::ADD_STOP, req_ptr->type);
// 		auto* req_ptr_2 = &dynamic_cast<AddStopRequest&>(*req_ptr);
// 		auto& stop = req_ptr_2->stop;
// 		ASSERT_EQUAL("Tolstopaltsevo", stop->name);
// 		ASSERT_EQUAL(55.611087, stop->latitude);
// 		ASSERT_EQUAL(37.20829, stop->longitude);
// 	}
// 	{
// 		string input = "Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka"; 
// 		stringstream sstream(input);
// 		auto req_ptr = ReadAddRequest(sstream);
// 		//ASSERT_EQUAL(true, req_ptr->route.has_value());
// 		//ASSERT_EQUAL(false, req_ptr->stop.has_value());
// 		ASSERT_EQUAL(AddRequest::Type::ADD_ROUTE, req_ptr->type);
// 		auto* req_ptr_2 = &dynamic_cast<AddRouteRequest&>(*req_ptr);
// 		auto& route = req_ptr_2->route;
// 		ASSERT_EQUAL("750", route->bus);
// 		list<string> stops = {"Tolstopaltsevo", "Marushkino", "Rasskazovka"};
// 		ASSERT_EQUAL(stops, route->stops);
// 		ASSERT_EQUAL(false, route->is_circular);
// 	}
// 	{
// 		string input = 
// 			"Bus 750: Tolstopaltsevo > Marushkino > Rasskazovka > Tolstopaltsevo"; 
// 		stringstream sstream = stringstream(input);
// 		auto req_ptr = ReadAddRequest(sstream);
// 		//ASSERT_EQUAL(true, req_ptr->route.has_value());
// 		//ASSERT_EQUAL(false, req_ptr->stop.has_value());
// 		ASSERT_EQUAL(AddRequest::Type::ADD_ROUTE, req_ptr->type);
// 		auto* req_ptr_2 = &dynamic_cast<AddRouteRequest&>(*req_ptr);
// 		auto& route = req_ptr_2->route;
// 		ASSERT_EQUAL("750", route->bus);
// 		list<string> stops = {"Tolstopaltsevo", "Marushkino", "Rasskazovka"};
// 		ASSERT_EQUAL(stops, route->stops);
// 		ASSERT_EQUAL(true, route->is_circular);
// 	}
// }

// void TestReadGetRequest() {
// 	stringstream sstream("Bus 256");
// 	auto ptr = ReadGetRequest(sstream);
// 	ASSERT_EQUAL(GetRequest::Type::GET_BUS_INFO, ptr->type);
// 	auto* ptr_2 = &dynamic_cast<GetBusRequest&>(*ptr);
// 	ASSERT_EQUAL("256", ptr_2->bus);
// }

// void TestGrader1() {
// 	stringstream sstream(R"(10
// Stop Tolstopaltsevo: 55.611087, 37.20829
// Stop Marushkino: 55.595884, 37.209755
// Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye
// Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka
// Stop Rasskazovka: 55.632761, 37.333324
// Stop Biryulyovo Zapadnoye: 55.574371, 37.6517
// Stop Biryusinka: 55.581065, 37.64839
// Stop Universam: 55.587655, 37.645687
// Stop Biryulyovo Tovarnaya: 55.592028, 37.653656
// Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164
// 3
// Bus 256
// Bus 750
// Bus 751
// )");
// 	string expected = 
// 	"Bus 256: 6 stops on route, 5 unique stops, 4371.02 route length\n"
// 	"Bus 750: 5 stops on route, 3 unique stops, 20939.5 route length\n"
// 	"Bus 751: not found\n"
// 	;
// 	stringstream output;

// 	Run(sstream, output);
// 	ASSERT_EQUAL(output.str(), expected);
// }


// void TestGrader2() {
// 	stringstream sstream(R"(13
// Stop Tolstopaltsevo: 55.611087, 37.20829
// Stop Marushkino: 55.595884, 37.209755
// Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye
// Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka
// Stop Rasskazovka: 55.632761, 37.333324
// Stop Biryulyovo Zapadnoye: 55.574371, 37.6517
// Stop Biryusinka: 55.581065, 37.64839
// Stop Universam: 55.587655, 37.645687
// Stop Biryulyovo Tovarnaya: 55.592028, 37.653656
// Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164
// Bus 828: Biryulyovo Zapadnoye > Universam > Rossoshanskaya ulitsa > Biryulyovo Zapadnoye
// Stop Rossoshanskaya ulitsa: 55.595579, 37.605757
// Stop Prazhskaya: 55.611678, 37.603831
// 6
// Bus 256
// Bus 750
// Bus 751
// Stop Samara
// Stop Prazhskaya
// Stop Biryulyovo Zapadnoye
// )");
// 	string expected = 
// "Bus 256: 6 stops on route, 5 unique stops, 4371.02 route length\n"
// "Bus 750: 5 stops on route, 3 unique stops, 20939.5 route length\n"
// "Bus 751: not found\n"
// "Stop Samara: not found\n"
// "Stop Prazhskaya: no buses\n"
// "Stop Biryulyovo Zapadnoye: buses 256 828\n";
// 	stringstream output;
// 	Run(sstream, output);
// 	ASSERT_EQUAL(output.str(), expected);
// }

// void TestGrader3() {
// 	stringstream sstream(R"(13
// Stop Tolstopaltsevo: 55.611087, 37.20829, 3900m to Marushkino
// Stop Marushkino: 55.595884, 37.209755, 9900m to Rasskazovka
// Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye
// Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka
// Stop Rasskazovka: 55.632761, 37.333324
// Stop Biryulyovo Zapadnoye: 55.574371, 37.6517, 7500m to Rossoshanskaya ulitsa, 1800m to Biryusinka, 2400m to Universam
// Stop Biryusinka: 55.581065, 37.64839, 750m to Universam
// Stop Universam: 55.587655, 37.645687, 5600m to Rossoshanskaya ulitsa, 900m to Biryulyovo Tovarnaya
// Stop Biryulyovo Tovarnaya: 55.592028, 37.653656, 1300m to Biryulyovo Passazhirskaya
// Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164, 1200m to Biryulyovo Zapadnoye
// Bus 828: Biryulyovo Zapadnoye > Universam > Rossoshanskaya ulitsa > Biryulyovo Zapadnoye
// Stop Rossoshanskaya ulitsa: 55.595579, 37.605757
// Stop Prazhskaya: 55.611678, 37.603831
// 6
// Bus 256
// Bus 750
// Bus 751
// Stop Samara
// Stop Prazhskaya
// Stop Biryulyovo Zapadnoye
// )");
// 	string expected = 
// R"(Bus 256: 6 stops on route, 5 unique stops, 5950 route length, 1.361239 curvature
// Bus 750: 5 stops on route, 3 unique stops, 27600 route length, 1.318084 curvature
// Bus 751: not found
// Stop Samara: not found
// Stop Prazhskaya: no buses
// Stop Biryulyovo Zapadnoye: buses 256 828
// )";
// 	stringstream output;
// 	Run(sstream, output);
// 	ASSERT_EQUAL(output.str(), expected);
// }

void TestParseAddStopJson() {
	stringstream s;
	s << R"({
  "base_requests": [
    {
      "type": "Stop",
      "road_distances": {
        "Marushkino": 3900
      },
      "longitude": 37.20829,
      "name": "Tolstopaltsevo",
      "latitude": 55.611087
    }
		]
})";
	Json::Document doc = Json::Load(s);
	auto root_node = doc.GetRoot().AsMap();
	auto add_requests_node = root_node["base_requests"];
	auto node_array = add_requests_node.AsArray();
	auto request = (GetAddRequestFromJson(node_array[0]));
	auto req = dynamic_cast<AddStopRequest*>(request.get());
	ASSERT_EQUAL(req->type, AddRequest::Type::ADD_STOP);
	ASSERT_EQUAL(req->stop->name, "Tolstopaltsevo");
	ASSERT_EQUAL(req->stop->latitude, 55.611087);
	ASSERT_EQUAL(req->stop->longitude, 37.20829);
	std::unordered_map<StopPair, int> distances {{StopPair("Tolstopaltsevo", "Marushkino"), 3900}};
	//ASSERT_EQUAL(req->distances, distances);
}

void TestParseAddRouteJson() {
	stringstream s;
	s << R"({
  "base_requests": [
    {
      "type": "Bus",
      "name": "256",
      "stops": [
        "Biryulyovo Zapadnoye",
        "Biryusinka",
        "Universam",
        "Biryulyovo Tovarnaya",
        "Biryulyovo Passazhirskaya",
        "Biryulyovo Zapadnoye"
      ],
      "is_roundtrip": true
    }
		]
})";
	Json::Document doc = Json::Load(s);
	auto root_node = doc.GetRoot().AsMap();
	auto add_requests_node = root_node["base_requests"];
	auto node_array = add_requests_node.AsArray();
	auto request = (GetAddRequestFromJson(node_array[0]));
	auto req = dynamic_cast<AddRouteRequest*>(request.get());
	ASSERT_EQUAL(req->type, AddRequest::Type::ADD_ROUTE);
	ASSERT_EQUAL(req->route->bus, "256");
	ASSERT_EQUAL(req->route->is_circular, true);
	std::vector<std::string> stops {
        "Biryulyovo Zapadnoye",
        "Biryusinka",
        "Universam",
        "Biryulyovo Tovarnaya",
        "Biryulyovo Passazhirskaya",
        "Biryulyovo Zapadnoye",
	};
	ASSERT_EQUAL(req->route->stops, stops);
}

void TestParseGetStopAndBusJson() {
	stringstream s;
	s << R"({
	"stat_requests": [
    {
      "type": "Bus",
      "name": "751",
      "id": 194217464
    },
    {
      "type": "Stop",
      "name": "Samara",
      "id": 746888088
    }
		]
})";
	Json::Document doc = Json::Load(s);
	auto root_node = doc.GetRoot().AsMap();
	auto get_requests_node = root_node["stat_requests"];
	auto node_array = get_requests_node.AsArray();
	{
		// 1
		auto request = (GetGetRequestFromJson(node_array[0]));
		auto req = dynamic_cast<GetBusRequest*>(request.get());
		ASSERT_EQUAL(req->type, GetRequest::Type::GET_BUS_INFO);
		ASSERT_EQUAL(req->bus, "751");
		ASSERT_EQUAL(req->id, 194217464);
	}
	{
		// 2
		auto request = (GetGetRequestFromJson(node_array[1]));
		auto req = dynamic_cast<GetStopRequest*>(request.get());
		ASSERT_EQUAL(req->type, GetRequest::Type::GET_STOP_INFO);
		ASSERT_EQUAL(req->stop, "Samara");
		ASSERT_EQUAL(req->id, 746888088);
	}
}

void TestParseGetRouteJson() {
	stringstream s;
	s << R"(
{
	"stat_requests": [
    {
      "type": "Route",
      "from": "Biryulyovo Zapadnoye",
      "to": "Universam",
      "id": 4
    },
    {
      "type": "Route",
      "from": "Biryulyovo Zapadnoye",
      "to": "Prazhskaya",
      "id": 5
    }
	]
})";
	auto root_node = Json::Load(s).GetRoot().AsMap();
	auto node_array = root_node.at("stat_requests").AsArray();
	{
		// 1
		auto request = (GetGetRequestFromJson(node_array[0]));
		auto req = dynamic_cast<GetRouteRequest*>(request.get());
		ASSERT_EQUAL(req->type, GetRequest::Type::GET_ROUTE_INFO);
		ASSERT_EQUAL(req->from, "Biryulyovo Zapadnoye");
		ASSERT_EQUAL(req->to, "Universam");
		ASSERT_EQUAL(req->id, 4);
	}
	{
		// 2
		auto request = (GetGetRequestFromJson(node_array[1]));
		auto req = dynamic_cast<GetRouteRequest*>(request.get());
		ASSERT_EQUAL(req->type, GetRequest::Type::GET_ROUTE_INFO);
		ASSERT_EQUAL(req->from, "Biryulyovo Zapadnoye");
		ASSERT_EQUAL(req->to, "Prazhskaya");
		ASSERT_EQUAL(req->id, 5);
	}
}

bool AreResponsesEqual(const Json::Node& lhs, const Json::Node& rhs) {
	const auto& l = lhs.AsMap();
	const auto& r = rhs.AsMap();
	// check that sets of keys are equal
	set<string> l_keys;
	for (const auto& [key, value] : l) {
		l_keys.insert(key);
	}
	set<string> r_keys;
	for (const auto& [key, value] : r) {
		r_keys.insert(key);
	}
	if (l_keys != r_keys) return false;
	// check that ids are equal
	if (l.at("request_id") != r.at("request_id")) return false;
	// if "total_time" key is present - compare only its value
	if (l_keys.find("total_time") != l_keys.end()) {
		return (abs(GetDouble(l.at("total_time")) - GetDouble(r.at("total_time"))) < 0.1 );
	}
	return (l == r);
}

void TestExample(string finput, string foutput) {
	ifstream example_input(finput);
	ifstream example_output(foutput);
	stringstream output;
	RunJson(example_input, output);
	auto example_responses = Json::Load(example_output).GetRoot().AsArray();
	auto responses = Json::Load(output).GetRoot().AsArray();
	ASSERT_EQUAL(example_responses.size(), responses.size());
	for (size_t i = 0; i < responses.size(); i++) {
		bool equal = AreResponsesEqual(example_responses[i], responses[i]);
		if (equal == false) {
			cerr << "Wrong response: " << endl;
			cerr << example_responses[i].AsMap().at("request_id") << endl;
			cerr << responses[i].AsMap().at("request_id") << endl;
			cerr << example_responses[i].AsMap().at("total_time") << endl;
			cerr << responses[i].AsMap().at("total_time") << endl;
			cerr << example_responses[i].AsMap().at("items").AsArray() << endl;
			cerr << responses[i] << endl;
			cerr << "is different from example: " << endl;
			cerr << example_responses[i] << endl;
		}
		ASSERT_EQUAL(equal, true);
	}
}

void TestExample1() { TestExample("example1_input.json", "example1_output.json"); }
void TestExample2() { TestExample("example2_input.json", "example2_output.json"); }
void TestExample3() { TestExample("example3_input.json", "example3_output.json"); }
void TestExample4() { TestExample("example4_input.json", "example4_output.json"); }

void RunTests() {
	TestRunner tr;
	RUN_TEST(tr, TestSplitBySubstring);
	// RUN_TEST(tr, TestReadAddRequest);
	// RUN_TEST(tr, TestReadGetRequest);
	//RUN_TEST(tr, TestGrader1);
	//RUN_TEST(tr, TestGrader2);
	//RUN_TEST(tr, TestGrader3);
	RUN_TEST(tr, TestParseAddStopJson);
	RUN_TEST(tr, TestParseAddRouteJson);
	RUN_TEST(tr, TestParseGetStopAndBusJson);
	RUN_TEST(tr, TestParseGetRouteJson);
	RUN_TEST(tr, TestExample1);
	RUN_TEST(tr, TestExample2);
	RUN_TEST(tr, TestExample3);
	RUN_TEST(tr, TestExample4);
	cerr << "Tests finished\n";
}
