#pragma once
#include <iostream>

// void Run(std::istream& is, std::ostream& os);
void RunJson(std::istream& is, std::ostream& os);