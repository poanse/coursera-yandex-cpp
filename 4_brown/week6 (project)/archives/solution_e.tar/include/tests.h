#pragma once
#include <list>
#include <string>
#include <iostream>

std::ostream& operator<< (std::ostream& os, const std::list<std::string>& list);

void RunTests();