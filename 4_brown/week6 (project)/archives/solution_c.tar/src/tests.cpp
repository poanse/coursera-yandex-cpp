#include "tests.h"
#include "test_runner.h"
#include "route.h"
#include "requests.h"
//#include "route_manager.h"
#include <iostream>

using namespace std;

ostream& operator<< (ostream& os, const list<string>& list) {
	auto it = list.begin();
	for (; it != prev(list.end()); it++) {
		os << '"' << *it << '"' << ", ";
	}
	os << '"' << *it << '"';
	return os;
}

void TestSplitBySubstring() {
	string str = "Tolstopaltsevo - Marushkino - Rasskazovka";
	auto l = SplitBySubstring(str, " - ");
	list<string> stops = {"Tolstopaltsevo", "Marushkino", "Rasskazovka"};
	ASSERT_EQUAL(l, stops);
}

void TestReadAddRequest() {
	{
		string input = "Stop Tolstopaltsevo: 55.611087, 37.20829\n";
		stringstream sstream(input);
		auto req_ptr = ReadAddRequest(sstream);
		ASSERT_EQUAL(AddRequest::Type::ADD_STOP, req_ptr->type);
		auto* req_ptr_2 = &dynamic_cast<AddStopRequest&>(*req_ptr);
		auto& stop = req_ptr_2->stop;
		ASSERT_EQUAL("Tolstopaltsevo", stop->name);
		ASSERT_EQUAL(55.611087, stop->latitude);
		ASSERT_EQUAL(37.20829, stop->longitude);
	}
	{
		string input = "Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka"; 
		stringstream sstream(input);
		auto req_ptr = ReadAddRequest(sstream);
		//ASSERT_EQUAL(true, req_ptr->route.has_value());
		//ASSERT_EQUAL(false, req_ptr->stop.has_value());
		ASSERT_EQUAL(AddRequest::Type::ADD_ROUTE, req_ptr->type);
		auto* req_ptr_2 = &dynamic_cast<AddBusRequest&>(*req_ptr);
		auto& route = req_ptr_2->route;
		ASSERT_EQUAL("750", route->bus);
		list<string> stops = {"Tolstopaltsevo", "Marushkino", "Rasskazovka"};
		ASSERT_EQUAL(stops, route->stops);
		ASSERT_EQUAL(false, route->is_circular);
	}
	{
		string input = 
			"Bus 750: Tolstopaltsevo > Marushkino > Rasskazovka > Tolstopaltsevo"; 
		stringstream sstream = stringstream(input);
		auto req_ptr = ReadAddRequest(sstream);
		//ASSERT_EQUAL(true, req_ptr->route.has_value());
		//ASSERT_EQUAL(false, req_ptr->stop.has_value());
		ASSERT_EQUAL(AddRequest::Type::ADD_ROUTE, req_ptr->type);
		auto* req_ptr_2 = &dynamic_cast<AddBusRequest&>(*req_ptr);
		auto& route = req_ptr_2->route;
		ASSERT_EQUAL("750", route->bus);
		list<string> stops = {"Tolstopaltsevo", "Marushkino", "Rasskazovka"};
		ASSERT_EQUAL(stops, route->stops);
		ASSERT_EQUAL(true, route->is_circular);
	}
}

void TestReadGetRequest() {
	stringstream sstream("Bus 256");
	auto ptr = ReadGetRequest(sstream);
	ASSERT_EQUAL(GetRequest::Type::GET_BUS_INFO, ptr->type);
	auto* ptr_2 = &dynamic_cast<GetBusRequest&>(*ptr);
	ASSERT_EQUAL("256", ptr_2->bus);
}

void TestGrader1() {
	stringstream sstream(R"(10
Stop Tolstopaltsevo: 55.611087, 37.20829
Stop Marushkino: 55.595884, 37.209755
Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye
Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka
Stop Rasskazovka: 55.632761, 37.333324
Stop Biryulyovo Zapadnoye: 55.574371, 37.6517
Stop Biryusinka: 55.581065, 37.64839
Stop Universam: 55.587655, 37.645687
Stop Biryulyovo Tovarnaya: 55.592028, 37.653656
Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164
3
Bus 256
Bus 750
Bus 751
)");
	string expected = 
	"Bus 256: 6 stops on route, 5 unique stops, 4371.02 route length\n"
	"Bus 750: 5 stops on route, 3 unique stops, 20939.5 route length\n"
	"Bus 751: not found\n"
	;
	stringstream output;

	RouteManager rm;
	size_t N, M;
	sstream >> N;
	ResponsePtr ptr;
	for (size_t i = 0; i < N; i++) {
		ptr = rm.ProcessAddRequest(ReadAddRequest(sstream));
	}
	sstream >> M;
	for (size_t i = 0; i < M; i++) {
		ptr = rm.ProcessGetRequest(ReadGetRequest(sstream));
		ProcessResponse(output, ptr.get());
	}
	ASSERT_EQUAL(output.str(), expected);
}


void TestGrader2() {
	stringstream sstream(R"(13
Stop Tolstopaltsevo: 55.611087, 37.20829
Stop Marushkino: 55.595884, 37.209755
Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye
Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka
Stop Rasskazovka: 55.632761, 37.333324
Stop Biryulyovo Zapadnoye: 55.574371, 37.6517
Stop Biryusinka: 55.581065, 37.64839
Stop Universam: 55.587655, 37.645687
Stop Biryulyovo Tovarnaya: 55.592028, 37.653656
Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164
Bus 828: Biryulyovo Zapadnoye > Universam > Rossoshanskaya ulitsa > Biryulyovo Zapadnoye
Stop Rossoshanskaya ulitsa: 55.595579, 37.605757
Stop Prazhskaya: 55.611678, 37.603831
6
Bus 256
Bus 750
Bus 751
Stop Samara
Stop Prazhskaya
Stop Biryulyovo Zapadnoye
)");
	string expected = 
"Bus 256: 6 stops on route, 5 unique stops, 4371.02 route length\n"
"Bus 750: 5 stops on route, 3 unique stops, 20939.5 route length\n"
"Bus 751: not found\n"
"Stop Samara: not found\n"
"Stop Prazhskaya: no buses\n"
"Stop Biryulyovo Zapadnoye: buses 256 828\n";
	stringstream output;

	RouteManager rm;
	size_t N, M;
	sstream >> N;
	ResponsePtr ptr;
	for (size_t i = 0; i < N; i++) {
		ptr = rm.ProcessAddRequest(ReadAddRequest(sstream));
	}
	sstream >> M;
	for (size_t i = 0; i < M; i++) {
		ptr = rm.ProcessGetRequest(ReadGetRequest(sstream));
		ProcessResponse(output, ptr.get());
	}
	ASSERT_EQUAL(output.str(), expected);
}

void TestGrader3() {
	stringstream sstream(R"(13
Stop Tolstopaltsevo: 55.611087, 37.20829, 3900m to Marushkino
Stop Marushkino: 55.595884, 37.209755, 9900m to Rasskazovka
Bus 256: Biryulyovo Zapadnoye > Biryusinka > Universam > Biryulyovo Tovarnaya > Biryulyovo Passazhirskaya > Biryulyovo Zapadnoye
Bus 750: Tolstopaltsevo - Marushkino - Rasskazovka
Stop Rasskazovka: 55.632761, 37.333324
Stop Biryulyovo Zapadnoye: 55.574371, 37.6517, 7500m to Rossoshanskaya ulitsa, 1800m to Biryusinka, 2400m to Universam
Stop Biryusinka: 55.581065, 37.64839, 750m to Universam
Stop Universam: 55.587655, 37.645687, 5600m to Rossoshanskaya ulitsa, 900m to Biryulyovo Tovarnaya
Stop Biryulyovo Tovarnaya: 55.592028, 37.653656, 1300m to Biryulyovo Passazhirskaya
Stop Biryulyovo Passazhirskaya: 55.580999, 37.659164, 1200m to Biryulyovo Zapadnoye
Bus 828: Biryulyovo Zapadnoye > Universam > Rossoshanskaya ulitsa > Biryulyovo Zapadnoye
Stop Rossoshanskaya ulitsa: 55.595579, 37.605757
Stop Prazhskaya: 55.611678, 37.603831
6
Bus 256
Bus 750
Bus 751
Stop Samara
Stop Prazhskaya
Stop Biryulyovo Zapadnoye
)");
	string expected = 
R"(Bus 256: 6 stops on route, 5 unique stops, 5950 route length, 1.361239 curvature
Bus 750: 5 stops on route, 3 unique stops, 27600 route length, 1.318084 curvature
Bus 751: not found
Stop Samara: not found
Stop Prazhskaya: no buses
Stop Biryulyovo Zapadnoye: buses 256 828
)";
	stringstream output;

	RouteManager rm;
	size_t N, M;
	sstream >> N;
	ResponsePtr ptr;
	for (size_t i = 0; i < N; i++) {
		ptr = rm.ProcessAddRequest(ReadAddRequest(sstream));
	}
	sstream >> M;
	for (size_t i = 0; i < M; i++) {
		ptr = rm.ProcessGetRequest(ReadGetRequest(sstream));
		ProcessResponse(output, ptr.get());
	}
	ASSERT_EQUAL(output.str(), expected);
}

void RunTests() {
	// TBD : cover code with unit tests:
	TestRunner tr;
	RUN_TEST(tr, TestSplitBySubstring);
	RUN_TEST(tr, TestReadAddRequest);
	RUN_TEST(tr, TestReadGetRequest);
	//RUN_TEST(tr, TestGrader1);
	//RUN_TEST(tr, TestGrader2);
	RUN_TEST(tr, TestGrader3);
	cerr << "Tests finished\n";
}
