#pragma once
#include <iostream>
#include <iomanip>
#include <optional>
#include <memory>
#include <unordered_map>

#include "route.h"

class AddRequest;
class AddBusRequest;
class AddStopRequest;
class GetRequest;
class GetBusRequest;

class Response;
class GetBusResponse;

using AddRequestPtr = std::unique_ptr<AddRequest>;
using AddBusPtr = std::unique_ptr<AddBusRequest>;
using AddStopPtr = std::unique_ptr<AddStopRequest>;

using GetRequestPtr = std::unique_ptr<GetRequest>;
using GetBusRequestPtr = std::unique_ptr<GetBusRequest>;

using ResponsePtr = std::unique_ptr<Response>;


class RouteManager {
	friend AddBusRequest;
	friend AddStopRequest;
	friend GetBusRequest;
private:
	std::unordered_map<std::string, RoutePtr> routes;
	Stops stops;

	const Route::Info* AddRoute(Route::InfoPtr route_info);
	void AddStop(StopPtr stop);

	Route::StatsPtr GetBusInfo(std::string bus);

public:
	ResponsePtr ProcessAddRequest(AddRequestPtr req);
	ResponsePtr ProcessGetRequest(GetRequestPtr req);
};


struct AddRequest {
	enum class Type {
		ADD_ROUTE, 
		ADD_STOP,
	};
	AddRequest::Type type;
	AddRequest(AddRequest::Type type_) : type(type_) {}
	virtual void Process(RouteManager *rm) = 0;
};

struct AddBusRequest : AddRequest {
	Route::InfoPtr route;

	AddBusRequest(AddRequest::Type type_, Route::InfoPtr ptr)
		:	AddRequest(type_)
		, route(move(ptr))
	{
	}

	void Process(RouteManager* rm) override {
		rm->AddRoute(move(route));
	}

};


struct AddStopRequest : AddRequest {
	StopPtr stop;
	AddStopRequest(AddRequest::Type type_, StopPtr ptr)
		:	AddRequest(type_)
		, stop(move(ptr))
	{
	}

	void Process(RouteManager* rm) override {
		rm->AddStop(move(stop));
	}
};

struct GetRequest {
	enum class Type {
		GET_BUS_INFO
	};
	GetRequest::Type type;
	GetRequest(GetRequest::Type type_) : type(type_) {}
	virtual ResponsePtr Process(RouteManager* rm) = 0;
};


struct Response {
	virtual void Process(std::ostream& os) const {};
	virtual ~Response() = default;
};

struct GetBusResponse : Response {
	Route::StatsPtr stats;
	std::string bus;

	GetBusResponse(Route::StatsPtr stats_, std::string bus_) 
		: stats(move(stats_))
		, bus(move(bus_))
	{
	}

	void Process(std::ostream& os) const override {
		os << std::setprecision(6);
		os << "Bus " << bus << ": ";
		if (stats) {
			os << stats->n_stops << " stops on route, " 
				 << stats->n_unique_stops << " unique stops, "
				 << stats->route_length * 1000 << " route length\n";
		} else {
			os << "not found\n";
		}
	}
	~GetBusResponse() override = default;
};

struct GetBusRequest : GetRequest {
	std::string bus;

	GetBusRequest(GetRequest::Type type_, std::string b)
		: GetRequest(type_)
		, bus(b)
	{
	}

	ResponsePtr Process(RouteManager* rm) override {
		auto *ptr = new GetBusResponse(rm->GetBusInfo(bus), move(bus));
		//std::unique_ptr<Response> resp = std::unique_ptr<GetBusResponse>(ptr);
		std::unique_ptr<Response> resp(ptr);
		return resp;
		//return std::make_unique<GetBusResponse>(rm->GetBusInfo(bus), move(bus));
	}
};



void ProcessResponse(std::ostream& os, const Response* resp);

AddRequestPtr ReadAddRequest(std::istream& is);

GetRequestPtr ReadGetRequest(std::istream& is);

std::ostream& operator<< (std::ostream& os, AddRequest::Type type);
std::ostream& operator<< (std::ostream& os, GetRequest::Type type);
