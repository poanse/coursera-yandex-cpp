#pragma once
#include <list>
#include <string>

std::ostream& operator<< (std::ostream& os, const std::list<std::string>& list);

//void TestSplitBySubstring();
//void TestReadAddRequest();
//void TestReadGetRequest();
//void TestGrader1();

void RunTests();
